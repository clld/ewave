
eWAVE data dump
===============

Data of eWAVE is published under the following license:
http://creativecommons.org/licenses/by/3.0/

It should be cited as

Kortmann, Bernd & Lunkenheimer, Kerstin (eds.) 2013.
The Electronic World Atlas of Varieties of English.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://ewave-atlas.org, Accessed on 2014-08-04.)


This package contains files in csv format [1] with corresponding schema descriptions in
JSON table schema [2] format, representing rows in database tables of the eWAVE web
application [3,4].

[1] http://csvlint.io/about
[2] http://dataprotocols.org/json-table-schema/
[3] http://ewave-atlas.org
[4] https://github.com/clld/ewave
